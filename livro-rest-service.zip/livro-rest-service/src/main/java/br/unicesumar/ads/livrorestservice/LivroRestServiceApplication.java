package br.unicesumar.ads.livrorestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivroRestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivroRestServiceApplication.class, args);
	}

}
