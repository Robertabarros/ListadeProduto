insert into livro (id, title, author, pages)
values (1, 'Matematica Discreta para Computacao e Informatica', 'Paulo Blauth Menezes', 370);

insert into livro (id, title, author, pages)
values (2, 'Desmistificando algoritmos', 'Thomas Cormen', 185);
